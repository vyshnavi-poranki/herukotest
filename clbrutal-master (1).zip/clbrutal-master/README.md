This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Client side for the Police Brutality Form

This project gives the user the ability to create, edit, and delete their task from the app.

### Tech Stack

* React

### License

Feel free to use parts of the code in your own projects with attribution.

### Author

Teri

[Check me out](https://teri.netlify.app/)