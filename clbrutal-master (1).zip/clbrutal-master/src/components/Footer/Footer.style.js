import styled from 'styled-components'

export const font = styled.div`

`