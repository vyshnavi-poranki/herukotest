import React from 'react';

export const Footer = () => (
  <div>
    <p>developed by Teri</p>
  </div>
);
