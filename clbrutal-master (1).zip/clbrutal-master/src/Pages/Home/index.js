export { default } from './Home.style';
